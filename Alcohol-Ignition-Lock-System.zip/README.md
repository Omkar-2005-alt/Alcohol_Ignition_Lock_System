# 🚗 Alcohol-Based Ignition Lock System Using NodeMCU

## 📌 Project Overview
The Alcohol-Based Ignition Lock System is a smart safety solution designed to prevent drunk driving using MQ-3 sensor and NodeMCU.

## ⚙️ Components
- NodeMCU (ESP8266)
- MQ-3 Alcohol Sensor
- LCD Display
- Buzzer
- DC Motor

## 🔧 Working
Detects alcohol → If above threshold → Ignition OFF → Alert ON

## 📂 Files
- report.docx
- code.ino
- images/

## 👨‍💻 Developed By
Your Name
