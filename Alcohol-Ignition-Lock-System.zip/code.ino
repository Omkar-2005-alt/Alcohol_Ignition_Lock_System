void setup() {
  Serial.begin(9600);
}

void loop() {
  Serial.println("Alcohol Detection Running...");
  delay(1000);
}
